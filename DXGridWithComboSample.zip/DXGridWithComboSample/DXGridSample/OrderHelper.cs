﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Markup;

namespace DXSample {
    public class OrderHelper {
        static Random rnd = new Random();

        public ObservableCollection<OrderName> OrderNames { get; private set; }
        public ObservableCollection<Order> Orders { get; private set; }

        public Order FocusedRow { get; set; }
        public ObservableCollection<Order> SelectedRows { get; set; }

        public OrderHelper() {
            int maxCount = 150;
            OrderNames = new ObservableCollection<OrderName>();
            for (int i = 100; i < maxCount; i++)
                OrderNames.Add(new OrderName { ID = i, Name = RandomStringHelper.GetRandomString() });

            Orders = new ObservableCollection<Order>();
            for (int i = 100; i < maxCount; i++)
                Orders.Add(new Order(OrderNames[rnd.Next(OrderNames.Count)].ID));
        }
    }

    public class ViewModelBase : INotifyPropertyChanged {
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        void RaisePropertyChanged(String propertyName) {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T storage, T value, string propertyName) {
            if ((storage == null && value == null) ||
                (storage != null && storage.Equals(value)))
                return false;

            storage = value;
            RaisePropertyChanged(propertyName);
            return true;
        }
        #endregion
    }

    public class OrderName : ViewModelBase {
        static Random rnd = new Random();

        int _ID;
        string _Name;

        #region Properties
        public string Name {
            get { return _Name; }
            set { SetProperty(ref _Name, value, "Name"); }
        }
        public int ID {
            get { return _ID; }
            set { SetProperty(ref _ID, value, "ID"); }
        }
        #endregion

        public OrderName() {
            ID = rnd.Next();
            Name = RandomStringHelper.GetRandomString();
        }
    }
    public class StringToDatatableConverter : MarkupExtension, IValueConverter
    {
        public StringToDatatableConverter() { }

        public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            List<string> lstBrokers = new List<string>();
            if (value == null)
                return null;

            Order drv = (value as Order);

            if (drv != null)
            {
                var tbl = System.Convert.ToString(drv.SuggestedBrokers).Split(',').ToList().Cast<string>().ToList();
                return tbl;
            }

            return lstBrokers;
        }

        public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return this;
        }
    }

    public class Order : ViewModelBase {
        static Random rnd = new Random();

        int _Name;
        string _suggestedBrokers;
        int _selectedBrokerIndex = -1;
        int _Amount;
        int _Price;
        bool _IsProcessed;

        #region Properties

        public int Name {
            get { return _Name; }
            set { SetProperty(ref _Name, value, "Name"); }
        }
        public string SuggestedBrokers
        {
            get { return _suggestedBrokers; }
            set { SetProperty(ref _suggestedBrokers, value, "SuggestedBrokers"); }
        }
        public int SelectedBrokerIndex
        {
            get { return _selectedBrokerIndex; }
            set { SetProperty(ref _selectedBrokerIndex, value, "SelectedBrokerIndex"); }
        }
        public int Amount {
            get { return _Amount; }
            set { SetProperty(ref _Amount, value, "Amount"); }
        }
        public int Price {
            get { return _Price; }
            set { SetProperty(ref _Price, value, "Price"); }
        }
        public bool IsProcessed {
            get { return _IsProcessed; }
            set { SetProperty(ref _IsProcessed, value, "IsProcessed"); }
        }

        #endregion

        public Order() { }
        public Order(int name = 0) {
            Name = name;
            SuggestedBrokers = "BANK1,BANK2";
            Amount = rnd.Next(-1000, 1000);
            Price = rnd.Next(0, 10000);
            IsProcessed = rnd.NextDouble() > 0.5;
        }

    }

    public class RandomStringHelper {
        static Random rnd = new Random();

        public static string GetRandomString(int min = 6, int max = 20) {
            StringBuilder strb = new StringBuilder();
            strb.Append(Char.ConvertFromUtf32(rnd.Next(0x41, 0x5A)));

            int length = rnd.Next(min, max);
            for (int i = 0; i < length - 1; i++)
                strb.Append(Char.ConvertFromUtf32(rnd.Next(0x61, 0x7A)));

            return strb.ToString();
        }
    }
}
